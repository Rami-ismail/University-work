#ifndef EX1_H
#define EX1_H

#endif // EX1_H

#include <iostream>
#include <cmath>
#include <fstream>
using namespace std;

int pgcd(int a, int b) {
    int r = a % b;
    while (r != 0) {
         a = b;
         b = r;
         r = a % b;
     }
     return b;
}

class Rational;
Rational operator+ (Rational r1, const Rational & r2);

class Rational {
public:
    Rational(int num, int denom = 1) : num(num), denom(denom) {
        int div = abs(pgcd(this->num, this->denom));
        this->num /= div;
        this->denom /= div;
    }

    Rational& operator+= (const Rational & r) {
        num = num * r.denom + r.num * denom;
        denom = denom * r.denom;
        return *this;
    }

    Rational operator-() const {
        return Rational(-num, denom);
    }

    Rational& operator-= (const Rational& r){
        return *this+= -r;
    }

    Rational operator- (const Rational & r) const {
        return *this + -r;
    }

    Rational& operator*= (const Rational& r){
        num*=r.num;
        denom*=r.denom;
        return *this;
    }

    Rational operator* (const Rational & r) const {
        int numerator = num * r.num;
        int denominator = denom * r.denom;
        return Rational(numerator, denominator);
    }

    ostream & toOstream(ostream & out) const {
        out << num << "/" << denom;
        return out;
    }

private:
    int num;
    int denom;
};

Rational operator+ (Rational r1, const Rational & r2) {
    r1 += r2;
    return r1;
}
ostream & operator<<(ostream & out, const Rational & r) {
    return r.toOstream(out);
}
