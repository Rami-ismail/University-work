#include <iostream>
#include <cmath>
#include <fstream>
#include "ex1.h"


int main(){
    double a = 5;
    double b = 5;
    double c = 0;

    c += a += b;

    Rational r0(2, 4);
    Rational r1(3);
    Rational r2 = -r1;
    Rational addition = r0;
    addition += r2;
    Rational subs = r0 - r1;
    Rational mult = r0 * r1;
    cout << r0 << " + " << r2 << " = " << addition << endl;
    cout << r0 << " - " << r1 << " = " << subs << endl;
    cout << r0 << " * " << r1 << " = " << mult << endl;
    Rational r3(1, 4);
    cout << r0 << " + " << r3 << " = " << r0 + r3 << endl;

    return 0;
}
