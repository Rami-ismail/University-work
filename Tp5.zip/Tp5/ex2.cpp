#include<iostream>
#include<vector>
using namespace std;

class LinkedList {
public:
//constructeur
    LinkedList(const vector<short> & v = {});
    LinkedList(const LinkedList & l);

    short & operator[] (int index);
    short operator[] (int index) const;
    LinkedList & operator= (LinkedList l);

    void push_back(short val);
    void push_front(short val);
    int getSize() const;

    ostream & toOstream(ostream & out) const;
    ~LinkedList();//destructeur

    friend void swap(LinkedList & l1, LinkedList & l2);
private:
      struct ListNode {
          ListNode(short val, ListNode * next = nullptr) : val(val), next(next)
          {}
          short val;
          ListNode *next;
      };
      ListNode * first;
      int size;
};


void affiche(const LinkedList & l) {
    for(int i = 0; i < l.getSize(); ++i) {
      cout << l[i] << " -> ";
     }
    cout << "X" << endl;
}


LinkedList::LinkedList(const vector<short> & v):size(v.size()){
    if (size==0) {
        first=nullptr;
        return;
    }
    ListNode* noeud=new ListNode(v[size-1],nullptr);
    for (size_t i=1; i<size ;++i){
        noeud=new ListNode(v[size-i-1],noeud);
    }
    first = noeud;
}

LinkedList::LinkedList(const LinkedList & l) : size(l.size) {
    ListNode* noeud=new ListNode(l[size-1],nullptr);
    for (size_t i=1; i<size ;++i){
        noeud= new ListNode(l[size-i-1],noeud);
    }
    first=noeud;
}


short & LinkedList::operator[] (int index){
    ListNode* noeud=first;
    for (size_t i=0; i<index ;++i){
        noeud=noeud->next;
    }
    return noeud->val;
}


short LinkedList::operator[] (int index) const{
    ListNode* noeud=first;
    for (size_t i=0; i<index ;++i){
        noeud=noeud->next;
    }
    return noeud->val;
}

LinkedList & LinkedList::operator= (LinkedList l){
  swap(*this,l);
  return *this;
}
void LinkedList::push_front(short val){
    size+=1;
    first = new ListNode(val,first);
}
void LinkedList::push_back(short val) {
    if(first==nullptr){
        first=new ListNode(val);
        size+=1;
        return;
    }

    ListNode* noeud=first;
    for(size_t i=1; i<size ;++i){

        noeud=noeud->next;
    }
    noeud->next=new ListNode(val,nullptr);

    size+=1;

}
int LinkedList::getSize()const{return size;}


ostream& operator<<(ostream& out,const LinkedList & l){
    return l.toOstream(out);
}


ostream&LinkedList::toOstream(ostream&out)const{
  out<<"[";
  ListNode *noeud=first;
  while(noeud!=nullptr){
    out<<noeud->val<<" ";
    noeud=noeud->next;
  }
  out<<"]";
  return out;
}

void swap(LinkedList&l1,LinkedList&l2){
  swap(l1.size,l2.size);
  swap(l1.first,l2.first);
}


LinkedList::~LinkedList()
 {
   ListNode *noeud=first;
   ListNode *noeud2=first->next;
   delete noeud;


   for(size_t i=1; i<size ;++i){
     noeud=noeud2;
     noeud2=noeud2->next;
     delete noeud;
   }
}



int main() {
    LinkedList list0;
    cout << "list0 = " << list0 << endl;
    list0.push_back(20);
    cout << "list0 = " << list0 << endl;
    list0.push_back(30);
    cout << "list0 = " << list0 << endl;
    list0.push_front(10);
    cout << "list0 = " << list0 << endl;
    cout << endl;
    LinkedList list1({5});
    cout << "list1 = " << list1 << endl;
    list1.push_back(20);
    cout << "list1 = " << list1 << endl;
    list1.push_back(30);
    cout << "list1 = " << list1 << endl;
    list1.push_front(10);
    cout << "list1 = " << list1 << endl;
    cout << endl;
    LinkedList list0_bis;
    cout << "list0_bis = " << list0_bis << endl;
    list0_bis.push_front(10);
    cout << "list0_bis = " << list0_bis << endl;
    cout << endl;
    LinkedList list2({5, 3, 7});
    cout << "list2 = " << list2 << endl;
    cout << "list2[1] = " << list2[1] << endl;
    for(int i = 0; i < list2.getSize(); ++i) {
        list2[i] = list2[i] * 5;
    }
    cout << "list2 = " << list2 << endl;
    affiche(list2);
    return 0;
}
