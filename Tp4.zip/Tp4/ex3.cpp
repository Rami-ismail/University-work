#include <iostream>
#include <string>

using namespace std;

class Maison{
public:
    Maison(string adresse):
        adresse(adresse)
    {}

    void afficher() const;

private:
    string adresse;
};


class Personne{
public:
    Personne(string nom,Maison* m):
        nom(nom),m(m)
    {}

    void afficher() const;
    void echangerMaison(Personne& personne2);

private:
    string nom;
    Maison* m;
};




int main(){
    Maison rome("Rome");
    Personne giovanni("Giovanni", &rome);
    Personne pietro("Pietro", &rome);

    Maison rennes("Rennes");
    Personne jean("Jean", &rennes);
    Personne pierre("Pierre", &rennes);

    giovanni.afficher();
    jean.afficher();
    cout << endl;
    pietro.afficher();
    pierre.afficher();

    cout << endl;

    giovanni.echangerMaison(jean);
    cout << "appel de giovanni.echangerMaison(jean);" << endl;
    cout << endl;

    giovanni.afficher();
    jean.afficher();
    cout << endl;
    pietro.afficher();
    pierre.afficher();

    return 0;
}





void Maison::afficher() const{
    cout<<adresse;
}

void Personne::afficher() const{
    cout<<nom<<" habite à ";
    m->afficher();
    cout<<"."<<endl;
}

void Personne::echangerMaison(Personne& personne2){
    Maison* temp=m;
    m=personne2.m;
    personne2.m=temp;
}
