#include<iostream>
#include <string>
#include<cmath>
using namespace std;

int pgcd(int a, int b){
    if (a%b==0){
        return b;
    }
    return pgcd(b,a%b);
    }

class Rational{
    public:
     Rational(double num,double denom=1):
     num(num/abs(pgcd(num,denom))),denom(denom/abs(pgcd(num,denom)))
     {if (denom<=0){throw "invalid";}}
      

        double get_num() const{return num;}
        double get_denom() const{return denom;}
       
        void set_num(double num){this->num=num;}
        void set_denom(double denom){this->denom=denom;}

        Rational add (const Rational & r) const{
            Rational sum((get_num()*r.get_denom())+(r.get_num()*get_denom()),(get_denom()*r.get_denom()));
            return sum;
        }
        Rational negate() const{
           Rational negation(-get_num(),get_denom());
           return negation;
        }

        Rational subtract(const Rational & r) const{
            Rational sus(0);
            sus=add(r.negate());
            return sus;
        }
        Rational multiplication(const Rational & r) const{
            
            Rational multi(get_num()*r.get_num(),r.get_denom()*get_denom());
            return multi;

        }
        void display()const{
            cout<<get_num()<<"/"<<get_denom();
        }
       

    private:
    int num;
    int denom;
};




 void display(const Rational & r,const Rational & r2, string op){
            if (op=="+"){
                r.display();
                cout<<"+";
                r2.display();
                cout<<"=";
                r.add(r2).display();
                cout<<endl;
            }
            if (op=="-"){
                r.display();
                cout<<"-";
                r2.display();
                cout<<"=";
                r.subtract(r2).display();
                cout<<endl;
            }
            if (op=="x"){
                r.display();
                cout<<"x";
                r2.display();
                cout<<"=";
                r.multiplication(r2).display();
                cout<<endl;
            }
        }

   

   


int main() {
Rational r0(1, 2);
Rational r1(3);
Rational r2(1, 4);
display(r0,r1.negate(),"+");
display(r0,r1,"-");
display(r0,r1,"x");
display(r0,r2,"+");
}
//reflexion facultative : operator overload