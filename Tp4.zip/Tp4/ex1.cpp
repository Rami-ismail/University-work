#include <iostream>
#include <cmath>
using namespace std;

class Point{
    public:
        Point(double x,double y,double z):
     x(x),y(y),z(z)
     {}
        double get_x() const{return x;}
        double get_y() const{return y;}
        double get_z() const{return z;}
        void set_x(double x){this->x=x;}
        void set_y(double y){this->y=x;}
        void set_z(double z){this->z=x;}

        void afficher()const{
            cout<<"(";
            cout<<get_x()<<","<<get_y()<<","<<get_z();
            cout<<")";
        }
        double distance(Point P2)const{
            return sqrt(pow((get_x()-P2.get_x()),2)+pow((get_y()-P2.get_y()),2)+pow((get_z()-P2.get_z()),2));
        }
    private: 
        double x;
        double y;
        double z;
};



int main () {
    const Point p1(1, 1, 1);
    const Point p2(3, 3, 2);
    cout << "p1 = ";
    p1.afficher();
    cout << endl;
    cout << "p2 = ";
    p2.afficher();
    cout << endl;
    cout << "distance entre p1 et p2 = " << p1.distance(p2) << endl;

    return 0;
}
