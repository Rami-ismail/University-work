#include <iostream>
#include <string>
#include <vector>

using namespace std;

class Student;

void displayName(const Student& student);

class Course{
public:
    Course(const string& name, int credits):
        name(name), credits(credits)
    {}

    void setCredits(int nbr);
    string getName() const;
    void display() const;
    void add(const Student & student);

private:
   string name;
   int credits;
   vector<const Student*> students;
};

class Student{
public:
    Student()=default;
    Student(string name):
        name(name)
    {}


    string getName() const{ return name;}
    void add(Course& course);
    void display()const;

private:
    string name;
    vector<const Course*> courses;
};

//``````````````````````````````````````
int main(){
    Course italien("Italien", 2);
    Course espagnol("Espagnol", 2);
    Course sport("Activités sportives", 2);

    Student jean("Giovanni");
    jean.add(italien);
    jean.add(sport);

    italien.setCredits(4);

    Student paul("Pablo");
    paul.add(espagnol);
    paul.add(sport);

    espagnol.setCredits(4);

    sport.setCredits(3);

    // Affichage à la fin du main
    jean.display();
    paul.display();

    return 0;
}

//``````````````````````````````````````
void displayName(const Student& student){
    cout<<student.getName()<<" ";
}
//=====================================
void Course::setCredits(int nbr){
    credits=nbr;
}

string Course::getName() const{
    return name;
}

void Course::display() const{
    cout<<"Unite d'Enseignement (UE): "<<name<<", credits: "<<credits<<endl;
    cout<<"Etudiants inscrits: ";
    for(size_t i=0; i<students.size(); ++i){
        displayName(*students[i]);
    }
    cout<<endl;
}

void Course::add(const Student & student){
    students.push_back(&student);
}
//=====================================
void Student::add(Course& course){
    courses.push_back(&course);
    course.add(*this);
}

void Student::display() const{
    cout<<"L'etudiant "<<name<<" est inscrit dans:"<<endl;
    for(size_t i=0; i<courses.size(); ++i){
        courses[i]->display();
    }
    cout<<endl;
}
//=====================================
