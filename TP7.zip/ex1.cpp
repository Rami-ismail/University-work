#include <iostream>
using namespace std;

class Composant {
public:
	virtual int getSortie() const = 0 {}
};

class Interrupteur :public Composant {

private:
	int val;
public:
	Interrupteur() :
		val(0) {}
	int getSortie() const override { return val; }
	void toggle() {
		if (val == 0) { val = 1; }
		else { val = 0; }
	}
};

class Negation :public Composant {

private:
	Composant& e;
public:
	Negation(Composant& c) :
		e(c)
	{}
	int getSortie() const override {
		if (e.getSortie() == 1) { return 0; }
		else { return 1; }
	}

};


class Composant2E : public Composant {
protected:
	const Composant& Entree0;
	const Composant& Entree1;
public:
	Composant2E(const Composant& c1, const Composant& c2) :
		Entree0(c1), Entree1(c2)
	{}
};

class PorteAnd :public Composant2E {
public:
	PorteAnd(const Composant& c1, const Composant& c2) :Composant2E(c1, c2) {}

	int getSortie()const override {

		if (Entree0.getSortie() == 1 && Entree1.getSortie() == 1) { return 1; }
		else { return 0; }
	}
};

class PorteOr :public Composant2E {
public:
	PorteOr(const Composant& c1, const Composant& c2) :Composant2E(c1, c2) {}

	int getSortie()const override {

		if (Entree0.getSortie() == 1 || Entree1.getSortie() == 1) { return 1; }
		else { return 0; }
	}
};

class PorteXor :public Composant2E {
public:
	PorteXor(const Composant& c1, const Composant& c2) :Composant2E(c1, c2) {}

	int getSortie()const override {

		if ((Entree0.getSortie() == 1 && Entree1.getSortie() == 1) || (Entree0.getSortie() == 0 && Entree1.getSortie() == 0)) { return 1; }

		else { return 0; }
	}
};

class PorteNand :public Composant2E {
public:
	PorteNand(const Composant& c1, const Composant& c2) :Composant2E(c1, c2) {}

	int getSortie()const override {
		if (Entree0.getSortie() == 0 && Entree1.getSortie() == 0 || (Entree0.getSortie() == 0 && Entree1.getSortie() == 1) || (Entree0.getSortie() == 1 && Entree1.getSortie() == 0)) { return 1; }
		else { return 0; }
	}
};




ostream& operator<<(ostream& out, const Composant& c) {
	out << c.getSortie();
	return out;
}
void testComposant2E(const Composant2E& p, const string& nomPorte, Interrupteur& i0,
	Interrupteur& i1) {
	// On consid�re que les interrupteurs pass�s � cette m�thode sont initialement � 0.
	cout << nomPorte << endl;
	cout << "-----------" << endl;
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 0
	i1.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	cout << "-----------" << endl;
	cout << endl;
	i0.toggle(); // reset to 0
	i1.toggle(); // reset to 0
}

int main(int argc, const char* argv[]) {

	Interrupteur i;

	Negation notGate(i);


	cout << "NOT " << i << " = " << notGate << endl;
	i.toggle();
	cout << "NOT " << i << " = " << notGate << endl;
	cout << endl;

	Interrupteur i0, i1;

	PorteAnd andGate(i0, i1);

	testComposant2E(andGate, "and", i0, i1);

	PorteOr orGate(i0, i1);

	testComposant2E(orGate, "or", i0, i1);

	PorteNand nandGate(i0, i1);

	testComposant2E(nandGate, "nand", i0, i1);

	PorteXor xorGate(i0, i1);

	testComposant2E(xorGate, "xor", i0, i1);

	return 0;
}