#include <iostream>
//bonus
#include<fstream>
#include<sstream>
using namespace std;

class Composant {
public:
	virtual int getSortie() const = 0 {}
};

class Interrupteur :public Composant {

private:
	int val;
public:
	Interrupteur() :
		val(0) {}
	int getSortie() const override { return val; }
	void toggle() {
		if (val == 0) { val = 1; }
		else { val = 0; }
	}
};

class Negation :public Composant {

private:
	Composant& e;
public:
	Negation(Composant& c) :
		e(c)
	{}
	int getSortie() const override {
		if (e.getSortie() == 1) { return 0; }
		else { return 1; }
	}

};


class Composant2E : public Composant {
protected:
	const Composant& Entree0;
	const Composant& Entree1;
public:
	Composant2E(const Composant& c1,const Composant& c2) :
		Entree0(c1), Entree1(c2)
	{}
};

class PorteAnd :public Composant2E {
public:
	PorteAnd(const Composant& c1,const Composant& c2) :Composant2E(c1, c2) {}
	
	int getSortie()const override {

		if (Entree0.getSortie() == 1 && Entree1.getSortie() == 1) { return 1; }
		else { return 0; }
	}
};

class PorteOr :public Composant2E {
public:
	PorteOr(const Composant& c1,  const Composant& c2) :Composant2E(c1, c2) {}

	int getSortie()const override {

		if (Entree0.getSortie() == 1 || Entree1.getSortie() == 1) { return 1; }
		else { return 0; }
	}
};

class PorteXor :public Composant2E {
public:
	PorteXor(const Composant& c1, const Composant& c2) :Composant2E(c1, c2) {}

	int getSortie()const override {

		if ((Entree0.getSortie() == 1 && Entree1.getSortie() == 1) || (Entree0.getSortie() == 0 && Entree1.getSortie() == 0)) { return 1; }

		else { return 0; }
	}
};

class PorteNand :public Composant2E {
public:
	PorteNand(const Composant& c1, const Composant& c2) : Composant2E(c1, c2)
	
	{}

	int getSortie()const override {
		if (Entree0.getSortie() == 0 && Entree1.getSortie() == 0 || (Entree0.getSortie() == 0 && Entree1.getSortie() == 1) || (Entree0.getSortie() == 1 && Entree1.getSortie() == 0)) { return 1; }
		else { return 0; }
	}

};

class Adder :public Composant {
public:
	virtual int getCarry() const = 0 {}
	virtual int getSortie() const = 0 {}
};

ostream& operator<< (ostream& out, const Adder& c) {
	out << c.getSortie() << "\t" << c.getCarry() << endl;
	return out;
}

class HalfAdder : public Adder {
public:
	HalfAdder(const Composant& entree0, const Composant& entree1) :
		or0(entree0, entree1), and0(entree0, entree1), not0(and0), and1(or0, not0) 
	{}

	int getSortie() const override {
		return and1.getSortie();
	}

	int getCarry() const override{
		return and0.getSortie();
	}

private:
	PorteOr or0;
	PorteAnd and0;
	Negation not0;
	PorteAnd and1;
};

ostream& operator<< (ostream& out, const HalfAdder& c) {
	out << c.getSortie() << "\t" << c.getCarry() << endl;
	return out;
}



class HalfAdderCarryAdapter : public Composant{
public:
	HalfAdderCarryAdapter(const HalfAdder& ha) : ha(ha) {

	}

	int getSortie() const override{
		return ha.getCarry();
	}

private:
	const HalfAdder& ha;
};

class FullAdder :public Adder {
private:
	HalfAdder HA0;
	HalfAdder HA1;
	HalfAdderCarryAdapter HACA0;
	HalfAdderCarryAdapter HACA1;
	PorteOr or0;
public:
	FullAdder(const Composant& entree0, const Composant& entree1, const Composant& entree2) :
		HA0(entree0, entree1), HACA0(HA0), HA1(HA0, entree2), HACA1(HA1), or0(HACA0, HACA1)
	{}
	int getSortie() const override { return HA1.getSortie(); }
	int getCarry() const override{ return or0.getSortie(); }
};









ostream& operator<<(ostream& out, const Composant& c) {
	out << c.getSortie();
	return out;
}
void testComposant2E(const Composant2E& p, const string& nomPorte, Interrupteur& i0,
	Interrupteur& i1) {
	// On consid�re que les interrupteurs pass�s � cette m�thode sont initialement � 0.
	cout << nomPorte << endl;
	cout << "-----------" << endl;
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 0
	i1.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	cout << "-----------" << endl;
	cout << endl;
	i0.toggle(); // reset to 0
	i1.toggle(); // reset to 0
}

void afficherLigne(Interrupteur& i0, Interrupteur& i1, const HalfAdder& ha) {
	cout << i0 << "\t" << i1 << "\t\t" << ha << endl;
}
void afficherLigne(Interrupteur& a, Interrupteur& b, Interrupteur& cin, const FullAdder& fa) {
	cout << a << "\t" << b << "\t" << cin << "\t\t" << fa << endl;
}
//bonus
void ecrireLigne(Interrupteur& a, Interrupteur& b, Interrupteur& cin, const FullAdder& fa) {
	ofstream outputfile;
	
	outputfile.open("outputfa.txt");
	
	if (outputfile.is_open()) {
		outputfile.clear();
		outputfile << "A\tB\tCin\t\tSUM\tCARRY\n";
	}
	outputfile << a << "\t" <<b << "\t\t" << fa << endl;
	outputfile.close();

}

void ecrireLigne(Interrupteur& i0, Interrupteur& i1, const HalfAdder& ha) {
	ofstream outputfile;
	stringstream  ss;
	string line;
	while (getline(ss, line)) {
		ss << line;
	}
	outputfile.open("outputha.txt");
	outputfile << "A\tB\tCin\t\tSUM\tCARRY\n";
	for(ss.len)
	outputfile << i0 << "\t" << i1 << "\t\t" << ha << endl;
	outputfile.close();
	
	
}
//bonus
int main(int argc, const char* argv[]) {

	Interrupteur i0, i1, cin;

	FullAdder fa(i0, i1, cin);

	cout << "A\tB\tCin\t\tSUM\tCARRY\n";
	afficherLigne(i0, i1, cin, fa);// 0 0 0
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //1
	afficherLigne(i0, i1, cin, fa); // 0 0 1
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //0
	i1.toggle(); // 1
	afficherLigne(i0, i1, cin, fa); // 0 1 0
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //1
	afficherLigne(i0, i1, cin, fa); // 0 1 1
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //0
	i1.toggle(); // 0
	i0.toggle(); // 1
	afficherLigne(i0, i1, cin, fa); // 1 0 0
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //1
	afficherLigne(i0, i1, cin, fa); // 1 0 1
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //0
	i1.toggle(); // 1
	afficherLigne(i0, i1, cin, fa); // 1 1 0
	ecrireLigne(i0, i1, cin, fa);
	cin.toggle(); //1
	afficherLigne(i0, i1, cin, fa); // 1 1 1
	ecrireLigne(i0, i1, cin, fa);
	cout << endl;

	return 0;
}