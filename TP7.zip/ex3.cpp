#include <iostream>
#include <string>
#include <vector>

using namespace std;

const int NO_OUTPUT = -1;


class Composant {
public:

    Composant() : memoire(NO_OUTPUT)
    {}


    int getSortie() {

        if (memoire == NO_OUTPUT) {
            recalculer();
        }
        return memoire;
    }


    void recalculer() {
        memoire = doRecalculer();

        for (auto c : consommateurs) {
            c->recalculer();

        }
    }

    void ajouterConsommateur(Composant& c) {
        consommateurs.push_back(&c);
    }
    virtual ~Composant() {
    }

protected:
    virtual int doRecalculer() const = 0;

private:
    int memoire;
    vector<Composant*> consommateurs;
};

class Interrupteur : public Composant {
public:
    Interrupteur(int val = 0) : val(val)
    {
        recalculer(); 
    }

    int doRecalculer() const {
        return val;
    }

    void toggle() {

        if (val == 0) {val = 1;}
        else{ val = 0;}
        recalculer();
    }

private:
    int val;
};


class Negation : public Composant {
public:
    Negation(Composant& c) : e(c)
    {
        e.ajouterConsommateur(*this);
        recalculer();
    }

    int doRecalculer() const {
        if (e.getSortie() == 1) {return 0;}
        else {return 1;  }
    }
private:
    Composant& e;

};

class Composant2E {
public:
    Composant2E(Composant& e1, Composant& e2) : Entree0(e1), Entree1(e2)
    {}

    virtual int getSortie() const = 0;


protected:
    Composant& Entree0;
    Composant& Entree1;
};



class PorteAnd :public Composant2E {
public:
    PorteAnd( Composant& c1,  Composant& c2) :Composant2E(c1, c2) {}

    int getSortie()const override {

        if (Entree0.getSortie() == 1 && Entree1.getSortie() == 1) { return 1; }
        else { return 0; }
    }
};

class PorteOr :public Composant2E {
public:
    PorteOr( Composant& c1,  Composant& c2) :Composant2E(c1, c2) {}

    int getSortie()const override {

        if (Entree0.getSortie() == 1 || Entree1.getSortie() == 1) { return 1; }
        else { return 0; }
    }
};

class PorteXor :public Composant2E {
public:
    PorteXor( Composant& c1,  Composant& c2) :Composant2E(c1, c2) {}

    int getSortie()const override {

        if ((Entree0.getSortie() == 1 && Entree1.getSortie() == 1) || (Entree0.getSortie() == 0 && Entree1.getSortie() == 0)) { return 1; }

        else { return 0; }
    }
};

class PorteNand :public Composant2E {
public:
    PorteNand( Composant& c1,  Composant& c2) :Composant2E(c1, c2) {}

    int getSortie()const override {
        if (Entree0.getSortie() == 0 && Entree1.getSortie() == 0 || (Entree0.getSortie() == 0 && Entree1.getSortie() == 1) || (Entree0.getSortie() == 1 && Entree1.getSortie() == 0)) { return 1; }
        else { return 0; }
    }
};



ostream& operator<<(ostream& out,Composant& c) {
    out << c.getSortie();
    return out;
}
ostream& operator<<(ostream& out, Composant2E& c) {
    out << c.getSortie();
    return out;
}

void testComposant2E( Composant2E& p, const string& nomPorte, Interrupteur& i0,Interrupteur& i1) {
	// On consid�re que les interrupteurs pass�s � cette m�thode sont initialement � 0.
	cout << nomPorte << endl;
	cout << "-----------" << endl;
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 0
	i1.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	i0.toggle(); // 1
	cout << i0 << " " << nomPorte << " " << i1 << " = " << p << endl;
	cout << "-----------" << endl;
	cout << endl;
	i0.toggle(); // reset to 0
	i1.toggle(); // reset to 0
}


int main(int argc, const char* argv[])
{
    Interrupteur i;

    Negation notGate(i);

    cout << "NOT " << i << " = " << notGate << endl;

    i.toggle();
    cout << "NOT " << i << " = " << notGate << endl;
    cout << endl;

    Interrupteur i0, i1;

    PorteAnd AndGate(i0, i1);

    testComposant2E(AndGate, "and", i0, i1);

    PorteOr OrGate(i0, i1);
    testComposant2E(OrGate, "or", i0, i1);

    PorteNand nandGate(i0, i1);
    testComposant2E(nandGate, "nand", i0, i1);

    PorteXor xorGate(i0, i1);

    testComposant2E(xorGate, "xor", i0, i1);
}