#include <iostream>

using namespace std;

double ** create5(int n);
void fill(string s,double ** M,int n);
double ** mult(double ** Ma,double ** Mb,int n);
void display(double ** M,int n);


int main_ex5() {
    cout << "Taille: ";
    int n;
    cin >> n;
    double ** M1 = create5(n);
    fill("M1", M1, n);
    double ** M2 = create5(n);
    fill("M2", M2, n);
    double ** M = mult(M1, M2, n);

    cout << "M1" << endl;
    display(M1, n);
    cout << endl;
    cout << "*" << endl;
    cout << endl;
    cout << "M2" << endl;
    display(M2, n);
    cout << endl;
    cout << "=" << endl;
    cout << endl;
    cout << "M" << endl;
    display(M, n);
    delete [] M1;
    M1 = nullptr;
    delete [] M2;
    M2 = nullptr;
    delete [] M;
    M = nullptr;

    return 0;
}

double ** create5(int n){
    double** M = new double* [n];
    for (int i(0); i < n; ++i) {
        M[i] = new double[n];

    }
    return M;

}
void fill(string s,double ** M,int n){
    cout<<"Matrice "<<s<<":"<<endl;
    for(int i(0);i<n;++i){
        for(int j(0);j<n;++j){
            cout<<s<<"["<<i<<"]["<<j<<"] = ";
            cin>>M[i][j];
        }
    }
    cout<<endl;
}
double ** mult(double ** Ma,double ** Mb,int n){
    double** Mult = create5(n);
    for(int i(0);i<n;++i){
        for(int j(0);j<n;++j){
            for(int k(0);k<n;++k){
                Mult[i][j]+=Ma[i][k]*Mb[k][j];
            }
        }
    }
    return Mult;
}
void display(double ** M,int n){
    for(int i(0);i<n;++i){
        cout<<"| ";
        for(int j(0);j<n;++j){
            cout<<M[i][j]<<" ";
        }
        cout<<"|"<<endl;
    }
}
