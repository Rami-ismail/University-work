// ex1.cpp : This file contains the 'main' function. Program execution begins and ends there.
//

#include <iostream>
using namespace std;
//partie 1-2

void fill(double tab[],const int n);
void affiche(double tab[], const int n);
void reverse(double tab1[], const int n, double tab2[]);
void concat(double tab1[], const int n, double tab2[], const int M, double tab3[]);

//partie 3-4
const int C = 3;
void fill(double tab[][C], const int Ligne);
void affiche(double tab[][C], const int Ligne);
void reverse(double listvector[][C], int Ligne, double revlist[][C]);
void flatten(double listvector[][C], int Ligne, double flattenedlist[]);








int main_ex1()
{
        const int L = 3;
        double lv[L][C];
        fill(lv, L);
        affiche(lv, L);
        cout << endl;
        double rlv[L][C];
        reverse(lv, L, rlv);
        affiche(rlv, L);
        cout << endl;
        double l[L * C];
        flatten(lv, L, l);
        affiche(l, L * C);
        cout << endl;
        double rl[L * C];
        flatten(rlv, L, rl);
        affiche(rl, L * C);
        cout << endl;

        return 0;
}





//partie 1-2

void fill(double tab[], const int n) {
    double value;
    for (int i = 0; i < n; ++i) {
        cout << "Entrez la valeur � l'indexe " << i << " :";
        cin >> value;
        tab[i] = value;
    }
}
void affiche(double tab[], const int n){
    cout << "[ ";
    for (int i = 0; i < n; ++i) {
        cout << tab[i] << " ";
        }
    cout << " ]";
}


void reverse(double tab1[], const int n, double tab2[]) {


    for (int i =0; i < n; ++i) {
        tab2[i] = tab1[n - 1 - i];
    }

}
void concat(double tab1[], const int n, double tab2[], const int M, double tab3[]) {
    for (int i = 0; i < n; ++i) {
        tab3[i] = tab1[i];
        }
    for (int i=0;i<M;++i){
        tab3[n + i] = tab2[i];
    }
}


//partie 3-4
void fill(double tab[][C], const int Ligne) {

    cout << "On voudrai cr�er une matrice compos� de " << Ligne << " lignes et de " << C << " colonnes" << endl;
    for (int i = 0; i < Ligne; ++i) {
        cout << "saisissez la ligne numero " << i <<" : "<< endl;
        for (int j = 0; j < C; ++j) {
            cout << "Entrez la valeur � l'indexe " << j<<" :";
            cin >> tab[i][j];
        }
    }
}

void affiche(double tab[][C], const int Ligne) {

    for (int i = 0; i < Ligne; ++i) {
        cout << "[";
            for (int j = 0; j < C; ++j) {
                cout << tab[i][j]<<" ";
            }
            cout << "]" << endl;

    }
}

void reverse(double listvector[][C], int Ligne, double revlist[][C]) {
    for (int i = 0; i < Ligne; ++i) {
        for(int j = 0; j < C; ++j) {
            revlist[i][j] = listvector[i][C - j - 1];
        }
    }
}

void flatten(double listvector[][C], int Ligne, double flattenedlist[]) {

    for (int i = 0; i < Ligne; ++i) {
        flattenedlist[i] = listvector[0][i];
    }
    for (int i = 0; i < Ligne; ++i) {
        flattenedlist[i+Ligne] = listvector[1][i];
    }
    for (int i = 0; i < Ligne; ++i) {
        flattenedlist[i +(2* Ligne)] = listvector[2][i];
    }

}
