#include <iostream>
#include <string>

using namespace std;

//Partie 1

double* create(int n);
void display(string nom, double* v, int N);

//Partie 2

double* take(double* tab, int n);
double* drop(double* tab, int tailleTab, int n);

//======================================


int main_ex21()
{
    const int N=3;
    double* v=create(N);
    display("V",v,N);

    delete [] v;
    v=nullptr;

    return 0;
}

int main_ex22(){
    const int N=5;
    double* v=create(N);
    display("v",v,N);

    const int A=3;
    double* a=take(v,A);
    display("a",a,A);

    double* b=drop(v,N,A);
    display("b",b,N-A);

    delete [] v;
    delete [] a;
    delete [] b;
    v=nullptr;
    a=nullptr;
    b=nullptr;

    return 0;
}

//======================================

//Partie 1

double* create(int n){
    double* tab=new double[n];
    cout<<"Creation du tableau: "<<endl;
    for(int i=0;i<n;++i){
        cout<<"Entrez la valeur à l'indexe "<<i<<": "<<endl;
        cin>>tab[i];
    }
    return tab;
}

void display(string nom, double* v, int n){
    cout<<nom<<" = [ ";
    for(int i=0;i<n;++i){
        cout<<v[i]<<" ";
    }
    cout<<"]"<<endl;
}

//Partie 2

double* take(double* tab, int n){
    double* tab2=new double[n];

    for(int i=0;i<n;++i){
        tab2[i]=tab[i];
    }

    return tab2;
}

double* drop(double* tab, int tailleTab, int n){
    double* tab2=new double[tailleTab-n];

    for(int i=n;i<tailleTab;++i){
        tab2[i-n]=tab[i];
    }

    return tab2;
}




