// ex 3.cpp : This file contains the 'main' function. Program execution begins and ends there.

#include <cstdio>
using namespace std;
// � remplir par une impl�mentation de:
// preIncrement
// postIncrement

int preIncrement(int *nbre);
int  postIncrement(int *nbre);


void afficher(int a, int x) {
    printf("a = %i\n", a);
    //identique �: cout << "a = " << a << endl;
    printf("x = %i\n", x);
    //identique �: cout << "x = " << x << endl;
}
int main_ex3() {
    int a = 0;
    int x = 0;


    afficher(a, x);

    printf("===\n");
    //identique �: cout << "===" << endl;

    a = preIncrement(&x);
    afficher(a, x);

    printf("===\n");
    //identique �: cout << "===" << endl;

    a = postIncrement(&x);
    afficher(a, x);

    return 0;
}


int preIncrement(int* nbre) {

    int elmt = ++(*nbre);
    return elmt;
}

int postIncrement(int* nbre) {

    int elmt = (*nbre)++;
    return elmt;

}
