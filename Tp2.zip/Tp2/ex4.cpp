#include <iostream>
#include <vector>
#include <string>

using namespace std;

typedef vector<double> ligne;
typedef vector<ligne> matrice;

matrice create4(string name, int taille);
matrice mult(const matrice& m1,const matrice &m2);
void display(const matrice& m);

//===================================================

int main_ex4(){
    cout<<"Taille: ";
    int n;
    cin>>n;

    matrice M1=create4("M1", n);
    matrice M2=create4("M2", n);
    matrice M=mult(M1,M2);

    cout<<"M1"<<endl;
    display(M1);
    cout<<"\n*\n"<<endl;
    cout<<"M2"<<endl;
    display(M2);
    cout<<"\n=\n"<<endl;
    cout<<"M"<<endl;
    display(M);

    return 0;
}

//====================================================

matrice create4(string name, int taille){
    ligne l(taille);
    matrice m(taille,l);
    cout<<"Matrice "<<name<<": "<<endl;
    for(int i=0;i<taille;++i){
        for(int j=0;j<taille;++j){
            cout<<name<<"["<<i<<"]["<<j<<"] = ";
            cin>>m[i][j];
        }
    }
    return m;
}

matrice mult(const matrice& m1,const matrice &m2){
    ligne l(m1.size());
    matrice M(m1.size(),l);
    for(size_t I=0;I<m1.size();++I){
        for(size_t J=0;J<m1[0].size();++J){
            for(size_t i=0;i<m1.size();++i){
                M[I][J]+=m1[I][i]*m2[i][J];
            }
        }
    }
    return M;
}

void display(const matrice& m){
    for(size_t i=0;i<m.size();++i){
        cout<<"| ";
        for(size_t j=0;j<m[i].size();++j){
            cout<<m[i][j]<<" ";
        }
        cout<<"|"<<endl;
    }
}


